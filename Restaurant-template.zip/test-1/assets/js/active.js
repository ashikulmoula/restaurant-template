(function ($) {
  "use strict";

  jQuery(document).ready(function ($) {
    $(".homepage-slides").owlCarousel({
      items: 1,
      nav: true,
      dots: true,
      loop: true,
      autoplay: true,
      navText: [
        "<i class='fa fa-angle-left'></i>",
        "<i class='fa fa-angle-right'></i>",
      ],
    });
  });

  // browser slide carousel
  jQuery(document).ready(function ($) {
    $(".browser-slides").owlCarousel({
      items: 6,
      nav: true,
      dots: false,
      loop: true,
      autoplay: true,
      navText: [
        "<i class='fa fa-angle-left'></i>",
        "<i class='fa fa-angle-right'></i>",
      ],
      responsive: {
        0: {
          items: 2,
        },
        480: {
          items: 3,
        },
        700: {
          items: 4,
        },
        900: {
          items: 6,
        },
      },
    });
  });
  //resturent carousel
  jQuery(document).ready(function ($) {
    $(".resturent-slides, .resturent-slides-2").owlCarousel({
      items: 3,
      nav: true,
      dots: false,
      loop: true,
      autoplay: true,
      navText: [
        "<i class='fa fa-angle-left'></i>",
        "<i class='fa fa-angle-right'></i>",
      ],
      responsive: {
        0: {
          items: 1,
        },
        480: {
          items: 1,
        },
        700: {
          items: 2,
        },
        900: {
          items: 3,
        },
      },
    });
  });
  // slicknav

  $(function () {
    $(".main-menu").slicknav();
  });
})(jQuery);
